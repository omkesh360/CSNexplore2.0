# CSV Import Sample Data

Fill in these CSV files with your real data, then import them into the database.

## Files

| File | Table | Key Fields |
|------|-------|------------|
| `vendors_sample.csv` | `vendors` | Import this FIRST — other tables reference vendor_id |
| `cars_sample.csv` | `cars` | price_per_day, fuel_type, transmission, seats |
| `stays_sample.csv` | `stays` | price_per_night, amenities, room_type, max_guests |
| `bikes_sample.csv` | `bikes` | price_per_day, fuel_type, cc |
| `restaurants_sample.csv` | `restaurants` | price_per_person, cuisine, menu_highlights |
| `attractions_sample.csv` | `attractions` | entry_fee, opening_hours, best_time |
| `buses_sample.csv` | `buses` | from_location, to_location, departure_time, arrival_time |

## Notes

- `vendor_id` refers to the row number (1, 2, 3...) from vendors_sample.csv after import
- `amenities`, `features`, `menu_highlights` are comma-separated strings stored as TEXT in DB
- `badge` can be left empty — just leave the column blank
- `is_active` defaults to 1 (visible), no need to include in CSV
- `rating` is 0–10 scale, `reviews` is the count
- For `entry_fee = 0` in attractions, it means free entry
- For bikes with `fuel_type = Electric`, set `cc = 0`
- Image paths should match files in your `/public/images/` folder

## Import Order

1. vendors_sample.csv → vendors table
2. cars_sample.csv → cars table
3. stays_sample.csv → stays table
4. bikes_sample.csv → bikes table
5. restaurants_sample.csv → restaurants table
6. attractions_sample.csv → attractions table
7. buses_sample.csv → buses table
